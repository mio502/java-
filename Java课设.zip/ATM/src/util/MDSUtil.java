package util;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class MDSUtil {
    public static String md5(String str){
        byte[] digest=null;
        try {
            MessageDigest md5=MessageDigest.getInstance("md5");
            digest=md5.digest(str.getBytes(StandardCharsets.UTF_8));
        }catch (Exception e){
            e.printStackTrace();
        }
        assert digest != null;
        return new BigInteger(1,digest).toString(16);
    }

    public static void main(String[] args) {
        System.out.println(md5("admin"));
    }
}
