package dao;

import bean.User;

public interface CustomerDAO {
    public void kaihu(User user);
    public void xiaohu(User user);
}
