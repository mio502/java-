package dao;

import bean.Customer;

public interface AdminDAO {
    public void cunkuan(Customer customer);
    public void qukuan(Customer customer);
    public void zhuanzhang(Customer customer);
    public void daikuan(Customer customer);
    public void huankuan(Customer customer);
    public void chaxun(Customer customer);
    public void weihu(Customer customer);
    public void guashi(Customer customer);
    public void jiegua(Customer customer);
    public Customer getByCount(String count);
}
