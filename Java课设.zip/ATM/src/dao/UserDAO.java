package dao;

import bean.User;

public interface UserDAO {
    public User getById(String count);
    public void kaihu(User user);
    public void xiaohu(User user);
    public void weihu(User user);
    public void kaihux(User user);
    public void xiaohux(User user);
}
