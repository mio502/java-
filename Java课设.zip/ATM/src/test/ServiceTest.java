package test;

import bean.Customer;
import bean.User;
import org.junit.Test;
import service.AdminService;
import service.CustomerService;
import service.UserService;

import java.util.Map;
import java.util.Scanner;

public class ServiceTest {
    public static void main(String[] args) throws Exception{
        User x=new User();
        Customer c=new Customer();
        float money;
        UserService userService=new UserService();
        AdminService adminService=new AdminService();
        CustomerService customerService=new CustomerService();
        User user=new User();
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入账号:");
        user.setCount(scanner.next());
        System.out.println("请输入密码:");
        user.setPassword(scanner.next());
        Map<String ,Object> map=userService.checkLogin(user);
        if (map.get("code").equals(0)){
            System.out.println("登录成功");
            System.out.println(map.get("msg"));
            User admin= (User) map.get("user");
            int choice=adminMenu();
            while (true){
                switch (choice){
                    case 1:
                        System.out.println("请输入想要开户的账号");
                        x.setCount(scanner.next());
                        System.out.println("请输入想要开户的密码");
                        x.setPassword(scanner.next());
                        System.out.println("请输入姓名");
                        x.setUserName(scanner.next());
                        x.setCarName("客户");
                        x.setRoleName("客户");
                        userService.insert(x);
                        customerService.insert(x);
                        System.out.println("开户成功");
                        break;
                    case 2:
                        x=new User();
                        System.out.println("请输入想要销户的账号");
                        x.setCount(scanner.next());
                        userService.delete(x);
                        customerService.delete(x);
                        System.out.println("销户成功");
                        break;
                    case 3:
                        c=new Customer();
                        System.out.println("请输入要存款的账户");
                        c.setcCount(scanner.next());
                        System.out.println("请输入要存款的钱");
                        money=scanner.nextFloat();
                        adminService.moneyUp(c,money);
                        System.out.println("存款成功");
                        break;
                    case 4:
                        c=new Customer();
                        System.out.println("请输入要取款的账户");
                        c.setcCount(scanner.next());
                        System.out.println("请输入要取出的钱");
                        money=scanner.nextFloat();
                        adminService.moneyDown(c,money);
                        System.out.println("取款成功");
                        break;
                    case 5:
                        c=new Customer();
                        Customer b=new Customer();
                        System.out.println("请输入转账人账户:");
                        c.setcCount(scanner.next());
                        System.out.println("请输入收账人账户:");
                        b.setcCount(scanner.next());
                        System.out.println("请输入金额");
                        money=scanner.nextFloat();
                        adminService.zhuan(c,b,money);
                        System.out.println("转账成功");
                        break;
                    case 6:
                        c=new Customer();
                        System.out.println("请输入要贷款的账户:");
                        c.setcCount(scanner.next());
                        System.out.println("请输入贷款金额:");
                        money=scanner.nextFloat();
                        adminService.loanUp(c,money);
                        System.out.println("贷款成功");
                        break;
                    case 7:
                        c=new Customer();
                        System.out.println("请输入要还款的账户:");
                        c.setcCount(scanner.next());
                        System.out.println("请输入还款金额:");
                        money=scanner.nextFloat();
                        adminService.loanDown(c,money);
                        System.out.println("贷款成功");
                        break;
                    case 8:
                        c=new Customer();
                        System.out.println("输入余额:");
                        c.setMoney(scanner.nextFloat());
                        System.out.println("输入名字:");
                        c.setcName(scanner.next());
                        System.out.println("输入密码:");
                        c.setPassword(scanner.next());
                        System.out.println("输入贷款:");
                        c.setLoan(scanner.nextFloat());
                        System.out.println("输入锁定状态:");
                        c.setSuoding(scanner.nextInt());
                        adminService.gengxin(c);
                        System.out.println("维护成功");
                        break;
                    case 9:
                        c=new Customer();
                        System.out.println("请输入想要挂失的账户:");
                        c.setcCount(scanner.next());
                        adminService.gua(c);
                        System.out.println("挂失成功");
                        break;
                    case 10:
                        c=new Customer();
                        System.out.println("请输入想要解挂的账户:");
                        c.setcCount(scanner.next());
                        adminService.jie(c);
                        System.out.println("解挂成功");
                        break;
                    case 11:
                        System.exit(0);
                        break;
                }
                choice=adminMenu();
            }
        }else if (map.get("code").equals(-1)){
            System.out.println("登录成功");
            System.out.println(map.get("msg"));
            User customer=(User)map.get("user");
            Customer customer1=adminService.getMoneyAndLoan(customer.getCount());
            int choice=customerMenu();
            while (true){
                switch (choice){
                    case 1:
                        adminService.gua(customer1);
                        System.out.println("锁定成功");
                        break;
                    case 2:
                        System.out.println("请输入想要存入的钱");
                        money=scanner.nextFloat();
                        adminService.moneyDown(customer1,money);
                        System.out.println("存款成功");
                        break;
                    case 3:
                        System.out.println("请输入想要取出的钱");
                        money=scanner.nextFloat();
                        adminService.moneyDown(customer1,money);
                        System.out.println("取款成功");
                        break;
                    case 4:
                        System.out.println("请输入想要转账的账户");
                        c.setcCount(scanner.next());
                        System.out.println("请输入想要转账的金额");
                        money=scanner.nextFloat();
                        adminService.moneyDown(customer1,money);
                        adminService.moneyUp(c,money);
                        System.out.println("转账成功");
                        break;
                    case 5:
                        System.out.println("请输入想要贷款的钱");
                        money=scanner.nextFloat();
                        adminService.loanUp(customer1,money);
                        System.out.println("贷款成功");
                        break;
                    case 6:
                        System.out.println("请输入想要还款的钱");
                        money=scanner.nextFloat();
                        adminService.loanDown(customer1,money);
                        System.out.println("还款成功");
                        break;
                    case 7:
                        adminService.chaxun(customer1);
                        System.out.println("查询成功");
                        break;
                    case 8:
                    case 9:
                        System.exit(0);
                        break;

                }
                choice=customerMenu();
            }
        }else {
            System.out.println(map.get("msg"));
        }
    }
    public static int adminMenu(){
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入选择");
        System.out.println("1.开户");
        System.out.println("2.销户");
        System.out.println("3.存款");
        System.out.println("4.取款");
        System.out.println("5.转账");
        System.out.println("6.贷款");
        System.out.println("7.还款");
        System.out.println("8.用户信息维护");
        System.out.println("9.挂失");
        System.out.println("10.解挂");
        System.out.println("11.退出");
        return scanner.nextInt();
    }
    public static int customerMenu(){
        Scanner scanner=new Scanner(System.in);
        System.out.println("1.账户锁定");
        System.out.println("2.存款");
        System.out.println("3.取款");
        System.out.println("4.转账");
        System.out.println("5.贷款");
        System.out.println("6.还款");
        System.out.println("7.查询");
        System.out.println("8.改密");
        System.out.println("9.退出");
        return scanner.nextInt();
    }
}
