package service;

import bean.Customer;
import dao.AdminDAO;
import dao.CustomerDAO;
import org.apache.ibatis.session.SqlSession;
import util.MybatisUtils;

import java.util.HashMap;
import java.util.Map;

public class AdminService {
    private AdminDAO adminDAO=null;
    private SqlSession sqlSession=null;
    public AdminService(){
        this.sqlSession= MybatisUtils.getSqlSession();
        this.adminDAO=sqlSession.getMapper(AdminDAO.class);
    }
    public Customer getMoneyAndLoan(String  count){
        Customer customer1=this.adminDAO.getByCount(count);
        return customer1;
    }
    public void moneyUp(Customer customer,float money) throws Exception{
        Customer customer2=getMoneyAndLoan(customer.getcCount());
        float x=customer2.getMoney()+money;
        customer2.setMoney(x);
        this.adminDAO.cunkuan(customer2);
        sqlSession.commit();
    }
    public void moneyDown(Customer customer,float money)throws Exception{
        Customer customer1=getMoneyAndLoan(customer.getcCount());
        float x=customer1.getMoney()-money;
        customer1.setMoney(x);
        this.adminDAO.qukuan(customer1);
        sqlSession.commit();
    }
    public void loanUp(Customer customer,float loan)throws Exception{
        Customer customer1=getMoneyAndLoan(customer.getcCount());
        float x=customer1.getLoan()+loan;
        customer1.setLoan(x);
        this.adminDAO.daikuan(customer1);
        sqlSession.commit();
    }
    public void loanDown(Customer customer,float loan)throws Exception{
        Customer customer1=getMoneyAndLoan(customer.getcCount());
        float x=customer1.getLoan()-loan;
        customer1.setLoan(x);
        this.adminDAO.huankuan(customer1);
        sqlSession.commit();
    }
    public void gengxin(Customer customer){
        this.adminDAO.weihu(customer);
    }
    public void gua(Customer customer){
        this.adminDAO.guashi(customer);

    }
    public void jie(Customer customer){
        this.adminDAO.jiegua(customer);
    }
    public void zhuan(Customer customer1,Customer customer2,float money)throws Exception{
        this.moneyDown(customer1,money);
        this.moneyUp(customer2,money);
    }
    public void chaxun(Customer customer){
        Customer customer1=getMoneyAndLoan(customer.getcCount());
        customer1.toString();
    }
}
