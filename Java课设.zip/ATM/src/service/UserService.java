package service;

import bean.User;
import dao.CustomerDAO;
import dao.UserDAO;
import org.apache.ibatis.session.SqlSession;
import util.MDSUtil;
import util.MybatisUtils;

import java.util.HashMap;
import java.util.Map;

public class UserService {
    private UserDAO userDAO=null;
    private SqlSession sqlSession=null;
    public UserService(){
        this.sqlSession= MybatisUtils.getSqlSession();
        this.userDAO=sqlSession.getMapper(UserDAO.class);
    }
    //登录检查,Map形式返回检查结果
    public Map<String ,Object> checkLogin(User user) throws Exception{
        Map<String ,Object> map=new HashMap<>();
        try {
            User foundUser=this.userDAO.getById(user.getCount());
            if (foundUser==null){
                map.put("code",1);
                map.put("msg","账号不存在");
            }else {
                String password=user.getPassword();
                if (!foundUser.getPassword().equals(password)){
                    map.put("code",1);
                    map.put("msg","密码不正确");
                }else {
                    if (foundUser.getCarName().equals("管理员")){
                        map.put("code",-0);
                        map.put("msg","欢迎管理员登录");
                        map.put("user",foundUser);
                    }else {
                        if (foundUser.getCarName().equals("客户")) {
                            map.put("code", -1);
                            map.put("msg", "欢迎客户登录");
                            map.put("user", foundUser);
                        }
                    }
                }
            }
        }catch (Exception e){
            map.put("code",1);
            map.put("msg",e.getMessage());
        }
        return map;
    }
    public void insert(User user)throws Exception{
        this.userDAO.kaihu(user);
        sqlSession.commit();
    }
    public void delete(User user)throws Exception{
        this.userDAO.xiaohu(user);
        sqlSession.commit();
    }
    public void update(User user)throws Exception{
        this.userDAO.weihu(user);
    }
}
