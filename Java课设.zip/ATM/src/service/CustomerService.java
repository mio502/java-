package service;

import bean.User;
import dao.CustomerDAO;
import org.apache.ibatis.session.SqlSession;
import util.MybatisUtils;

public class CustomerService {
    public CustomerDAO customerDAO=null;
    private SqlSession sqlSession;
    public CustomerService(){
        sqlSession = MybatisUtils.getSqlSession();
        this.customerDAO= sqlSession.getMapper(CustomerDAO.class);
    }
    public void insert(User user){
        this.customerDAO.kaihu(user);
        sqlSession.commit();
    }
    public void delete(User user){
        this.customerDAO.xiaohu(user);
        sqlSession.commit();
    }
}
