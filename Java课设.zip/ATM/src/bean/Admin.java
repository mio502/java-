package bean;

public class Admin {
    private String aCount;
    private String aName;

    @Override
    public String toString() {
        return "admin{" +
                "aCount='" + aCount + '\'' +
                ", aName='" + aName + '\'' +
                ", aPassword='" + aPassword + '\'' +
                '}';
    }

    public Admin(){}
    public Admin(String aCount, String aName, String aPassword) {
        this.aCount = aCount;
        this.aName = aName;
        this.aPassword = aPassword;
    }

    private String aPassword;

    public String getaCount() {
        return aCount;
    }

    public void setaCount(String aCount) {
        this.aCount = aCount;
    }

    public String getaName() {
        return aName;
    }

    public void setaName(String aName) {
        this.aName = aName;
    }

    public String getaPassword() {
        return aPassword;
    }

    public void setaPassword(String aPassword) {
        this.aPassword = aPassword;
    }
}
