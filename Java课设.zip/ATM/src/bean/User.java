package bean;

public class User {
    private String count;
    private String carName;
    private String password;
    private String roleName;
    private String userName;

    public User(){}
    @Override
    public String toString() {
        return "admin{" +
                "count='" + count + '\'' +
                ", carName='" + carName + '\'' +
                ", password='" + password + '\'' +
                ", roleName='" + roleName + '\'' +
                ", userName='" + userName + '\'' +
                '}';
    }

    public User(String count, String carName, String password, String roleName, String userName) {
        this.count = count;
        this.carName = carName;
        this.password = password;
        this.roleName = roleName;
        this.userName = userName;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
