package bean;

public class Customer {
    private String cCount;
    private float money;
    private String cName;
    private String password;
    private float loan;

    public Customer(){}
    public String toString() {
        return "customer{" +
                "cCount='" + cCount + '\'' +
                ", money=" + money +
                ", cName='" + cName + '\'' +
                ", password='" + password + '\'' +
                ", loan=" + loan +
                ", suoding=" + suoding +
                '}';
    }

    private int suoding;

    public Customer(String cCount, float money, String cName, String password, float loan, int suoding) {
        this.cCount = cCount;
        this.money = money;
        this.cName = cName;
        this.password = password;
        this.loan = loan;
        this.suoding = suoding;
    }

    public String getcCount() {
        return cCount;
    }

    public void setcCount(String cCount) {
        this.cCount = cCount;
    }

    public float getMoney() {
        return money;
    }

    public void setMoney(float money) {
        this.money = money;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public float getLoan() {
        return loan;
    }

    public void setLoan(float loan) {
        this.loan = loan;
    }

    public int getSuoding() {
        return suoding;
    }

    public void setSuoding(int suoding) {
        this.suoding = suoding;
    }
}
